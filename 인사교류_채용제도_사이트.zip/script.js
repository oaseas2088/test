document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll(".feature-list li");
  cards.forEach((card, index) => {
    card.style.opacity = "0";
    card.style.transform = "translateY(10px)";
    card.style.transition = "opacity .45s ease, transform .45s ease";
    setTimeout(() => {
      card.style.opacity = "1";
      card.style.transform = "translateY(0)";
    }, 80 * index);
  });
});
